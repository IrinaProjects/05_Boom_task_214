# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 1.1.0 (2021-06-04)


### Features

* add initial commit ([f256be3](https://gitlab.com/boomdotdev/boilerplates/html-css-sass-boilerplate/commit/f256be377d87bc736cfe6bae67b2535d72e19c52))
* add standard-version ([506b11d](https://gitlab.com/boomdotdev/boilerplates/html-css-sass-boilerplate/commit/506b11dc6221a21ae3919671f06ecfe71a24cd9d))
